# -*- coding: utf-8 -*- 

###########################################################################
## Python code generated with wxFormBuilder (version Jun 17 2015)
## http://www.wxformbuilder.org/
##
## PLEASE DO "NOT" EDIT THIS FILE!
###########################################################################
import matplotlib.pyplot
from scipy.integrate import odeint
import wx
#import wx.xrc
import numpy as np
import matplotlib
matplotlib.use('WXAgg')



###########################################################################
## Class MyFrame1
###########################################################################

class MyFrame1 ( wx.Frame ): #--------------------------------------LA CLASE MyFrame1 DEFINE LOS COMPONENTES DEL ENTORNO GRÁFICO-----------------------------------------
                            #----------------------------------------SE EMPLEAN COMPONENTES DEL PAQUETE WX-----------------------------------------------------------------
	
	def __init__( self, parent ):
		wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = u"Circuitos LR y RC", pos = wx.DefaultPosition, size = wx.Size( 637,664 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )
		
		self.SetSizeHints( wx.DefaultSize, wx.DefaultSize )
		
		bSizer1 = wx.BoxSizer( wx.VERTICAL )
		
		self.m_notebook1 = wx.Notebook( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_panel1 = wx.Panel( self.m_notebook1, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		bSizer2 = wx.BoxSizer( wx.VERTICAL )
		
		self.m_staticText14 = wx.StaticText( self.m_panel1, wx.ID_ANY, u"INDUCTOR + RESISTENCIA", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText14.Wrap( -1 )
		self.m_staticText14.SetFont( wx.Font( 9, 74, 90, 90, True, "Arial" ) )
		
		bSizer2.Add( self.m_staticText14, 0, wx.ALL|wx.ALIGN_CENTER_HORIZONTAL, 5 )
		
		self.m_staticText15 = wx.StaticText( self.m_panel1, wx.ID_ANY, u"Ecuación diferencial del circuito", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText15.Wrap( -1 )
		bSizer2.Add( self.m_staticText15, 0, wx.ALL|wx.ALIGN_CENTER_HORIZONTAL, 5 )
		
		self.m_bitmap1 = wx.StaticBitmap( self.m_panel1, wx.ID_ANY, wx.Bitmap( u"./imagenes/1.bmp", wx.BITMAP_TYPE_ANY ), wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer2.Add( self.m_bitmap1, 0, wx.ALL|wx.ALIGN_CENTER_HORIZONTAL, 5 )
		
		self.m_staticText16 = wx.StaticText( self.m_panel1, wx.ID_ANY, u"Al despejar la diferencial de la ecuación", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText16.Wrap( -1 )
		bSizer2.Add( self.m_staticText16, 0, wx.ALL|wx.ALIGN_CENTER_HORIZONTAL, 5 )
		
		self.m_bitmap5 = wx.StaticBitmap( self.m_panel1, wx.ID_ANY, wx.Bitmap( u"./imagenes/2.bmp", wx.BITMAP_TYPE_ANY ), wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer2.Add( self.m_bitmap5, 0, wx.ALL|wx.ALIGN_CENTER_HORIZONTAL, 5 )
		
		bSizer3 = wx.BoxSizer( wx.HORIZONTAL )
		
		self.m_bitmap2 = wx.StaticBitmap( self.m_panel1, wx.ID_ANY, wx.Bitmap( u"./imagenes/3.bmp", wx.BITMAP_TYPE_ANY ), wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer3.Add( self.m_bitmap2, 0, wx.ALL, 5 )
		
		fgSizer2 = wx.FlexGridSizer( 0, 3, 0, 0 )
		fgSizer2.SetFlexibleDirection( wx.BOTH )
		fgSizer2.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )
		
		self.m_staticText1 = wx.StaticText( self.m_panel1, wx.ID_ANY, u"L", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText1.Wrap( -1 )
		fgSizer2.Add( self.m_staticText1, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.textbox1 = wx.TextCtrl( self.m_panel1, wx.ID_ANY, u"1", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer2.Add( self.textbox1, 0, wx.ALL, 5 )
		
		self.m_staticText2 = wx.StaticText( self.m_panel1, wx.ID_ANY, u"mH", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText2.Wrap( -1 )
		fgSizer2.Add( self.m_staticText2, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.m_staticText3 = wx.StaticText( self.m_panel1, wx.ID_ANY, u"R", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText3.Wrap( -1 )
		fgSizer2.Add( self.m_staticText3, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.textbox2 = wx.TextCtrl( self.m_panel1, wx.ID_ANY, u"1", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer2.Add( self.textbox2, 0, wx.ALL, 5 )
		
		self.m_staticText4 = wx.StaticText( self.m_panel1, wx.ID_ANY, u"kΩ", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText4.Wrap( -1 )
		fgSizer2.Add( self.m_staticText4, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.m_staticText5 = wx.StaticText( self.m_panel1, wx.ID_ANY, u"V", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText5.Wrap( -1 )
		fgSizer2.Add( self.m_staticText5, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.textbox3 = wx.TextCtrl( self.m_panel1, wx.ID_ANY, u"1", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer2.Add( self.textbox3, 0, wx.ALL, 5 )
		
		self.m_staticText6 = wx.StaticText( self.m_panel1, wx.ID_ANY, u"V", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText6.Wrap( -1 )
		fgSizer2.Add( self.m_staticText6, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		
		bSizer3.Add( fgSizer2, 1, wx.ALIGN_CENTER_VERTICAL, 5 )
		
		
		bSizer2.Add( bSizer3, 1, wx.ALIGN_CENTER_HORIZONTAL, 5 )
		
		fgSizer4 = wx.FlexGridSizer( 0, 3, 0, 0 )
		fgSizer4.SetFlexibleDirection( wx.BOTH )
		fgSizer4.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )
		
		self.m_staticText45 = wx.StaticText( self.m_panel1, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText45.Wrap( -1 )
		fgSizer4.Add( self.m_staticText45, 0, wx.ALL, 5 )
		
		self.m_staticText27 = wx.StaticText( self.m_panel1, wx.ID_ANY, u"Parámetros", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText27.Wrap( -1 )
		fgSizer4.Add( self.m_staticText27, 0, wx.ALL|wx.ALIGN_CENTER_HORIZONTAL, 5 )
		
		self.m_staticText46 = wx.StaticText( self.m_panel1, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText46.Wrap( -1 )
		fgSizer4.Add( self.m_staticText46, 0, wx.ALL, 5 )
		
		fgSizer5 = wx.FlexGridSizer( 0, 3, 0, 0 )
		fgSizer5.SetFlexibleDirection( wx.BOTH )
		fgSizer5.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )
		
		self.m_staticText29 = wx.StaticText( self.m_panel1, wx.ID_ANY, u"i(0)", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText29.Wrap( -1 )
		fgSizer5.Add( self.m_staticText29, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL|wx.ALIGN_RIGHT, 5 )
		
		self.textbox4 = wx.TextCtrl( self.m_panel1, wx.ID_ANY, u"0.5", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer5.Add( self.textbox4, 0, wx.ALL, 5 )
		
		self.m_staticText35 = wx.StaticText( self.m_panel1, wx.ID_ANY, u"A", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText35.Wrap( -1 )
		fgSizer5.Add( self.m_staticText35, 0, wx.ALL, 5 )
		
		self.m_staticText30 = wx.StaticText( self.m_panel1, wx.ID_ANY, u"t", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText30.Wrap( -1 )
		fgSizer5.Add( self.m_staticText30, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL|wx.ALIGN_RIGHT, 5 )
		
		self.textbox5 = wx.TextCtrl( self.m_panel1, wx.ID_ANY, u"0.01", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer5.Add( self.textbox5, 0, wx.ALL, 5 )
		
		self.m_staticText36 = wx.StaticText( self.m_panel1, wx.ID_ANY, u"ms", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText36.Wrap( -1 )
		fgSizer5.Add( self.m_staticText36, 0, wx.ALL, 5 )
		
		
		fgSizer4.Add( fgSizer5, 1, wx.EXPAND, 5 )
		
		self.m_staticText34 = wx.StaticText( self.m_panel1, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText34.Wrap( -1 )
		fgSizer4.Add( self.m_staticText34, 0, wx.ALL, 5 )
		
		fgSizer7 = wx.FlexGridSizer( 0, 2, 0, 0 )
		fgSizer7.SetFlexibleDirection( wx.BOTH )
		fgSizer7.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )
		
		self.m_staticText31 = wx.StaticText( self.m_panel1, wx.ID_ANY, u"dt", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText31.Wrap( -1 )
		fgSizer7.Add( self.m_staticText31, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.textbox6 = wx.TextCtrl( self.m_panel1, wx.ID_ANY, u"0.0000001", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer7.Add( self.textbox6, 0, wx.ALL, 5 )
		
		self.m_staticText42 = wx.StaticText( self.m_panel1, wx.ID_ANY, u"Ls", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText42.Wrap( -1 )
		fgSizer7.Add( self.m_staticText42, 0, wx.ALL, 5 )
		
		self.textbox7 = wx.TextCtrl( self.m_panel1, wx.ID_ANY, u"0.01", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer7.Add( self.textbox7, 0, wx.ALL, 5 )
		
		
		fgSizer4.Add( fgSizer7, 1, wx.EXPAND, 5 )
		
		
		bSizer2.Add( fgSizer4, 1, wx.ALIGN_CENTER_HORIZONTAL, 5 )
		
		bSizer4 = wx.BoxSizer( wx.HORIZONTAL )
		
		self.button2 = wx.Button( self.m_panel1, wx.ID_ANY, u"Resolver", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer4.Add( self.button2, 0, wx.ALL, 5 )
		
		self.button1 = wx.Button( self.m_panel1, wx.ID_ANY, u"Gráfica de Comportamiento", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer4.Add( self.button1, 0, wx.ALL, 5 )
		
		
		bSizer2.Add( bSizer4, 1, wx.ALIGN_CENTER_HORIZONTAL, 5 )
		
		
		self.m_panel1.SetSizer( bSizer2 )
		self.m_panel1.Layout()
		bSizer2.Fit( self.m_panel1 )
		self.m_notebook1.AddPage( self.m_panel1, u"Circuito LR", False )
		self.m_panel2 = wx.Panel( self.m_notebook1, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		bSizer5 = wx.BoxSizer( wx.VERTICAL )
		
		self.m_staticText124 = wx.StaticText( self.m_panel2, wx.ID_ANY, u"RESISTENCIA + CONDENSADOR", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText124.Wrap( -1 )
		self.m_staticText124.SetFont( wx.Font( 9, 74, 90, 90, True, "Arial" ) )
		
		bSizer5.Add( self.m_staticText124, 0, wx.ALL|wx.ALIGN_CENTER_HORIZONTAL, 5 )
		
		self.m_staticText126 = wx.StaticText( self.m_panel2, wx.ID_ANY, u"Ecuación diferencial del circuito", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText126.Wrap( -1 )
		bSizer5.Add( self.m_staticText126, 0, wx.ALL|wx.ALIGN_CENTER_HORIZONTAL, 5 )
		
		self.m_bitmap18 = wx.StaticBitmap( self.m_panel2, wx.ID_ANY, wx.Bitmap( u"./imagenes/4.bmp", wx.BITMAP_TYPE_ANY ), wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer5.Add( self.m_bitmap18, 0, wx.ALL|wx.ALIGN_CENTER_HORIZONTAL, 5 )
		
		self.m_staticText127 = wx.StaticText( self.m_panel2, wx.ID_ANY, u"Al despejar la diferencial de la ecuación", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText127.Wrap( -1 )
		bSizer5.Add( self.m_staticText127, 0, wx.ALL|wx.ALIGN_CENTER_HORIZONTAL, 5 )
		
		self.m_bitmap19 = wx.StaticBitmap( self.m_panel2, wx.ID_ANY, wx.Bitmap( u"./imagenes/5.bmp", wx.BITMAP_TYPE_ANY ), wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer5.Add( self.m_bitmap19, 0, wx.ALL|wx.ALIGN_CENTER_HORIZONTAL, 5 )
		
		bSizer6 = wx.BoxSizer( wx.HORIZONTAL )
		
		self.m_bitmap4 = wx.StaticBitmap( self.m_panel2, wx.ID_ANY, wx.Bitmap( u"./imagenes/6.bmp", wx.BITMAP_TYPE_ANY ), wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer6.Add( self.m_bitmap4, 0, wx.ALL, 5 )
		
		fgSizer21 = wx.FlexGridSizer( 0, 3, 0, 0 )
		fgSizer21.SetFlexibleDirection( wx.BOTH )
		fgSizer21.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )
		
		self.m_staticText7 = wx.StaticText( self.m_panel2, wx.ID_ANY, u"R", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText7.Wrap( -1 )
		fgSizer21.Add( self.m_staticText7, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.textbox8 = wx.TextCtrl( self.m_panel2, wx.ID_ANY, u"1", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer21.Add( self.textbox8, 0, wx.ALL, 5 )
		
		self.m_staticText8 = wx.StaticText( self.m_panel2, wx.ID_ANY, u"kΩ", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText8.Wrap( -1 )
		fgSizer21.Add( self.m_staticText8, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.m_staticText9 = wx.StaticText( self.m_panel2, wx.ID_ANY, u"C", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText9.Wrap( -1 )
		fgSizer21.Add( self.m_staticText9, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.textbox9 = wx.TextCtrl( self.m_panel2, wx.ID_ANY, u"1", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer21.Add( self.textbox9, 0, wx.ALL, 5 )
		
		self.m_staticText10 = wx.StaticText( self.m_panel2, wx.ID_ANY, u" µF", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText10.Wrap( -1 )
		fgSizer21.Add( self.m_staticText10, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.m_staticText11 = wx.StaticText( self.m_panel2, wx.ID_ANY, u"V", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText11.Wrap( -1 )
		fgSizer21.Add( self.m_staticText11, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.textbox10 = wx.TextCtrl( self.m_panel2, wx.ID_ANY, u"1", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer21.Add( self.textbox10, 0, wx.ALL, 5 )
		
		self.m_staticText12 = wx.StaticText( self.m_panel2, wx.ID_ANY, u"V", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText12.Wrap( -1 )
		fgSizer21.Add( self.m_staticText12, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		
		bSizer6.Add( fgSizer21, 1, wx.ALIGN_CENTER_VERTICAL, 5 )
		
		
		bSizer5.Add( bSizer6, 1, wx.ALIGN_CENTER_HORIZONTAL, 5 )
		
		fgSizer24 = wx.FlexGridSizer( 0, 3, 0, 0 )
		fgSizer24.SetFlexibleDirection( wx.BOTH )
		fgSizer24.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )
		
		self.m_staticText128 = wx.StaticText( self.m_panel2, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText128.Wrap( -1 )
		fgSizer24.Add( self.m_staticText128, 0, wx.ALL|wx.ALIGN_CENTER_HORIZONTAL, 5 )
		
		self.m_staticText129 = wx.StaticText( self.m_panel2, wx.ID_ANY, u"Parámetros", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText129.Wrap( -1 )
		fgSizer24.Add( self.m_staticText129, 0, wx.ALL, 5 )
		
		self.m_staticText130 = wx.StaticText( self.m_panel2, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText130.Wrap( -1 )
		fgSizer24.Add( self.m_staticText130, 0, wx.ALL|wx.ALIGN_CENTER_HORIZONTAL, 5 )
		
		fgSizer25 = wx.FlexGridSizer( 0, 3, 0, 0 )
		fgSizer25.SetFlexibleDirection( wx.BOTH )
		fgSizer25.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )
		
		self.m_staticText132 = wx.StaticText( self.m_panel2, wx.ID_ANY, u"Vc(0)", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText132.Wrap( -1 )
		fgSizer25.Add( self.m_staticText132, 0, wx.ALL|wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.textbox11 = wx.TextCtrl( self.m_panel2, wx.ID_ANY, u"0.005", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer25.Add( self.textbox11, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.m_staticText133 = wx.StaticText( self.m_panel2, wx.ID_ANY, u"V", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText133.Wrap( -1 )
		fgSizer25.Add( self.m_staticText133, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.m_staticText134 = wx.StaticText( self.m_panel2, wx.ID_ANY, u"t", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText134.Wrap( -1 )
		fgSizer25.Add( self.m_staticText134, 0, wx.ALL|wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.textbox12 = wx.TextCtrl( self.m_panel2, wx.ID_ANY, u"6", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer25.Add( self.textbox12, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.m_staticText135 = wx.StaticText( self.m_panel2, wx.ID_ANY, u"ms", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText135.Wrap( -1 )
		fgSizer25.Add( self.m_staticText135, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		
		fgSizer24.Add( fgSizer25, 1, wx.EXPAND|wx.ALIGN_CENTER_HORIZONTAL, 5 )
		
		self.m_staticText131 = wx.StaticText( self.m_panel2, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText131.Wrap( -1 )
		fgSizer24.Add( self.m_staticText131, 0, wx.ALL, 5 )
		
		fgSizer26 = wx.FlexGridSizer( 0, 2, 0, 0 )
		fgSizer26.SetFlexibleDirection( wx.BOTH )
		fgSizer26.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )
		
		self.m_staticText136 = wx.StaticText( self.m_panel2, wx.ID_ANY, u"dt", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText136.Wrap( -1 )
		fgSizer26.Add( self.m_staticText136, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.textbox13 = wx.TextCtrl( self.m_panel2, wx.ID_ANY, u"0.000001", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer26.Add( self.textbox13, 0, wx.ALL, 5 )
		
		self.m_staticText44 = wx.StaticText( self.m_panel2, wx.ID_ANY, u"Ls", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText44.Wrap( -1 )
		fgSizer26.Add( self.m_staticText44, 0, wx.ALL, 5 )
		
		self.textbox14 = wx.TextCtrl( self.m_panel2, wx.ID_ANY, u"6", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer26.Add( self.textbox14, 0, wx.ALL, 5 )
		
		
		fgSizer24.Add( fgSizer26, 1, wx.EXPAND, 5 )
		
		
		bSizer5.Add( fgSizer24, 1, wx.ALIGN_CENTER_HORIZONTAL, 5 )
		
		bSizer8 = wx.BoxSizer( wx.HORIZONTAL )
		
		self.button4 = wx.Button( self.m_panel2, wx.ID_ANY, u"Resolver", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer8.Add( self.button4, 0, wx.ALL, 5 )
		
		self.button3 = wx.Button( self.m_panel2, wx.ID_ANY, u"Gráfica de Comportamiento", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer8.Add( self.button3, 0, wx.ALL, 5 )
		
		
		bSizer5.Add( bSizer8, 1, wx.ALIGN_CENTER_HORIZONTAL, 5 )
		
		
		self.m_panel2.SetSizer( bSizer5 )
		self.m_panel2.Layout()
		bSizer5.Fit( self.m_panel2 )
		self.m_notebook1.AddPage( self.m_panel2, u"Circuito RC", True )
		
		bSizer1.Add( self.m_notebook1, 1, wx.EXPAND |wx.ALL, 5 )
		
		
		self.SetSizer( bSizer1 )
		self.Layout()
		
		self.Centre( wx.BOTH )
		
		# Connect Events
		self.Bind( wx.EVT_CLOSE, self.MyFrame1OnClose )
		self.button2.Bind( wx.EVT_BUTTON, self.button2OnButtonClick )
		self.button1.Bind( wx.EVT_BUTTON, self.button1OnButtonClick )
		self.button4.Bind( wx.EVT_BUTTON, self.button4OnButtonClick )
		self.button3.Bind( wx.EVT_BUTTON, self.button3OnButtonClick )


	def __del__( self ):
		pass
	
	
	# Virtual event handlers, overide them in your derived class
	def MyFrame1OnClose( self, event ): #----------------------DEFINICIÓN EVENTO DE CIERRE DE LA VENTANA-------------------------
                
		event.Skip()
	
	def button1OnButtonClick( self, event ):#----------------------DEFINICIÓN EVENTO SE PRESIONA BOTON 1-------------------------
	                                   #--------ESTE BOTÓN TOMA LOS PARAMETROS INTRODUCIDOS Y GRAFICA EL COMPORTAMIENTO----------------
            try:
                L1 = float(self.textbox1.GetValue())/1000 #------------LECTURA DE LOS PARÁMETROS-----------------
                R1 = float(self.textbox2.GetValue())*1000
                V1 = float(self.textbox3.GetValue())
                i0 = float(self.textbox4.GetValue())
                dt = float(self.textbox6.GetValue())
                Ls = float(self.textbox7.GetValue())/1000
                
                def modeloLR(i,t, L, R, V):#-----------FUNCIÓN DE CALCULO DE LA DERIVADA DE LA CORRIENTE EN CIRCUITO LR 
                    didt = (V-R*i)/L
                    return(didt)            
                
                original = np.arange(0,Ls, dt)
                xoriginal = odeint(modeloLR, i0, original,args=(L1, R1, V1))#---------------INTEGRA EL RESULTADO DEVUELTO
                if (L1 <=0):
                    wx.MessageBox("L debe ser mayor a 0","Error")
                elif(R1<=0):
                    wx.MessageBox("R debe ser mayor 0","Error")
                elif(V1<=0):
                    wx.MessageBox("V debe ser mayor a 0","Error")
                elif(i0<=0):
                    wx.MessageBox("i(0) debe ser mayor a 0","Error")
                elif(Ls <= 0):
                    wx.MessageBox("Ls debe ser mayor a 0","Error")
                else:
                    #matplotlib.pyplot.figure()
                    matplotlib.pyplot.plot(original,xoriginal) #---------------GENERA LA GRAFICA EN BASE A LOS RESULTADOS DE LA INTEGRACIÓN
                    matplotlib.pyplot.title('Comportamiento de Corriente en Circuito LR')
                    matplotlib.pyplot.legend(['Comportamiento de la corriente'])
                    matplotlib.pyplot.ylabel('i')
                    matplotlib.pyplot.xlabel('t')
                    matplotlib.pyplot.show()
            except:
                wx.MessageBox('Ocurrió un error al cargar una librería o en la conversión de datos', "Error")
            event.Skip()
            
	
	
	def button2OnButtonClick( self, event ):#----------------------DEFINICIÓN EVENTO SE PRESIONA BOTON 2-------------------------
	                                   #--------ESTE BOTÓN TOMA LOS PARAMETROS INTRODUCIDOS CALCULA LA CORRIENTE EN t----------------
            try:
                L1 = float(self.textbox1.GetValue())/1000#------------LECTURA DE LOS PARÁMETROS-----------------
                R1 = float(self.textbox2.GetValue())*1000
                V1 = float(self.textbox3.GetValue())
                i0 = float(self.textbox4.GetValue())
                dt = float(self.textbox6.GetValue())
                Ls = float(self.textbox5.GetValue())/1000
        
                def modeloLR(i,t, L, R, V):#-----------FUNCIÓN DE CALCULO DE LA DERIVADA DE LA CORRIENTE EN CIRCUITO LR 
                    didt = (V-R*i)/L
                    return(didt)            
                
                original = np.arange(0,Ls, dt)
                xoriginal = odeint(modeloLR, i0, original,args=(L1, R1, V1))#---------------INTEGRA EL RESULTADO DEVUELTO
                if (L1 <=0):
                    wx.MessageBox("L debe ser mayor a 0","Error")
                elif(R1<=0):
                    wx.MessageBox("R debe ser mayor 0","Error")
                elif(V1<=0):
                    wx.MessageBox("V debe ser mayor a 0","Error")
                elif(i0<=0):
                    wx.MessageBox("i(0) debe ser mayor a 0","Error")
                elif(Ls <= 0):
                    wx.MessageBox("t debe ser mayor a 0","Error")
                else:
                    wx.MessageBox('El valor de I después de ' + str(Ls) + ' segundos es:' + str(xoriginal[-1]) + 'A.', "Respuesta")

            except:
                wx.MessageBox('Ocurrió un error al cargar una librería o en la conversión de datos', "Error")
            event.Skip()
	
	def button3OnButtonClick( self, event ):#----------------------DEFINICIÓN EVENTO SE PRESIONA BOTON 2-------------------------
	                                   #--------ESTE BOTÓN TOMA LOS PARAMETROS INTRODUCIDOS Y GRAFICA EL COMPORTAMIENTO----------------
            try:
                R1 = float(self.textbox8.GetValue())*1000  #------------LECTURA DE LOS PARÁMETROS-----------------
                C1 = float(self.textbox9.GetValue())/1000000
                V1 = float(self.textbox10.GetValue())
                vc0 = float(self.textbox11.GetValue())
                dt = float(self.textbox13.GetValue())
                Ls = float(self.textbox14.GetValue())/1000
                
                def modeloRC(vc,t, R, C, V): #-----------FUNCIÓN DE CALCULO DE LA DERIVADA DE LA CORRIENTE EN CIRCUITO RC
                    didt = (V-vc)/(R*C)
                    return(didt)         
                
                original = np.arange(0,Ls, dt)
                xoriginal = odeint(modeloRC, vc0, original,args=(R1, C1, V1))#---------------INTEGRA EL RESULTADO DEVUELTO
                if (C1 <=0):
                    wx.MessageBox("L debe ser mayor a 0","Error")
                elif(R1<=0):
                    wx.MessageBox("R debe ser mayor 0","Error")
                elif(V1<=0):
                    wx.MessageBox("V debe ser mayor a 0","Error")
                elif(vc0<=0):
                    wx.MessageBox("Vc debe ser mayor a 0","Error")
                elif(Ls <= 0):
                    wx.MessageBox("Ls debe ser mayor a 0","Error")
                else:
                    #matplotlib.pyplot.figure()
                    matplotlib.pyplot.plot(original,xoriginal)#---------------GENERA LA GRAFICA EN BASE A LOS RESULTADOS DE LA INTEGRACIÓN
                    matplotlib.pyplot.title('Comportamiento de Voltaje en Circuito RC')
                    matplotlib.pyplot.legend(['Comportamiento del voltaje'])
                    matplotlib.pyplot.ylabel('Vc')
                    matplotlib.pyplot.xlabel('t')
                    matplotlib.pyplot.show()
            except:
                wx.MessageBox('Ocurrió un error al cargar una librería o en la conversión de datos',"Error")
            event.Skip()

	def button4OnButtonClick( self, event ):
	    #----------------------DEFINICIÓN EVENTO SE PRESIONA BOTON 2-------------------------
	                                   #--------ESTE BOTÓN TOMA LOS PARAMETROS INTRODUCIDOS Y GRAFICA EL COMPORTAMIENTO----------------
            try:
                R1 = float(self.textbox8.GetValue())*1000  #------------LECTURA DE LOS PARÁMETROS-----------------
                C1 = float(self.textbox9.GetValue())/1000000
                V1 = float(self.textbox10.GetValue())
                vc0 = float(self.textbox11.GetValue())
                dt = float(self.textbox13.GetValue())
                Ls = float(self.textbox12.GetValue())/1000
                
                def modeloRC(vc,t, R, C, V):#-----------FUNCIÓN DE CALCULO DE LA DERIVADA DE LA CORRIENTE EN CIRCUITO RC
                    didt = (V-vc)/(R*C)
                    return(didt)         
                
                original = np.arange(0,Ls, dt)
                xoriginal = odeint(modeloRC, vc0, original,args=(R1, C1, V1)) #---------------INTEGRA EL RESULTADO DEVUELTO
                if (C1 <=0):
                    wx.MessageBox("L debe ser mayor a 0","Error")
                elif(R1<=0):
                    wx.MessageBox("R debe ser mayor 0","Error")
                elif(V1<=0):
                    wx.MessageBox("V debe ser mayor a 0","Error")
                elif(vc0<=0):
                    wx.MessageBox("Vc debe ser mayor a 0","Error")
                elif(Ls <= 0):
                    wx.MessageBox("t debe ser mayor 0","Error")
                else:
                    wx.MessageBox('El valor de Vc después de '+ str(Ls) +' segundos es:' + str(xoriginal[-1]) + 'V.', "Respuesta")
                
            except:
                wx.MessageBox('Ocurrió un error al cargar una librería o en la conversión de datos',"Error")
            event.Skip()

class MainApp(wx.App):
    def OnInit(self):
        mainFrame = MyFrame1(None)
        mainFrame.Show(True)
        return True

if __name__=='__main__':
    app=MainApp()
    app.MainLoop()


    


